import React from 'react'
import {Container, Col, Row, InputGroup, FormControl, Button} from 'react-bootstrap'
import axios from 'axios'


class InputCtr extends React.Component {

    constructor(){
        super()
        this.state = {
            seachText: ''

        }
        this.OnChangeSearch = this.OnChangeSearch.bind(this)
        this.fSearch = this.fSearch.bind(this)
    }

    sendData (responses) {
        this.props.parentCallback(responses.data);
   }

    OnChangeSearch(e){
        e.preventDefault()
        console.log(e.target.value)
        this.setState({seachText: e.target.value})
    }

    async fSearch() {
       const response = await axios.get('https://api.qrserver.com/v1/create-qr-code', { timeout: 3000,

            params: {
                data: this.state.seachText,
                size: '150x150'
            }
       })

        this.sendData(response)
    }


    render(){

            return (
                    <Container>
                        <Row>
                            <Col>
                                <InputGroup className="nb-3">
                                    <FormControl 
                                        placeholder="Datos para QR"
                                        aria-label="Datos para QR"
                                        aria-describedby="basic-addon2"
                                        onChange={(event) => this.OnChangeSearch(event)}
                                        />
                                <InputGroup.Append>
                                    <Button variant="outline-secondary"
                                        onClick={this.fSearch}
                                    >[Genera-QR]</Button>
                                </InputGroup.Append>
                                </InputGroup>
                            </Col>
                        </Row>                    
                    </Container>

            )

    }

}
export default InputCtr