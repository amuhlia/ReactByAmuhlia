import React from 'react'
import {Container, Col, Row} from 'react-bootstrap'
import utf8 from 'utf8'
import binaryToBase64 from 'binary-base64'


import InputCtr from '../inputCtr'
import ImageContainer from '../image_container'
import './inputSearch.css'

class ImageSearch extends React.Component {

    constructor(){
        super()
        this.state = { message: [], b64: binaryToBase64, ut8: utf8 }
    }

    callbackFunction = (childData) => {
        this.setState({message: childData, b64: binaryToBase64, ut8: utf8 })
        console.log('message', this.state.message)
    }
 
     render(){

            return (
      
                    <Container className="inputSearch">
                        <p>Gen-QR</p>
                        <Row>
                            <Col>
                                <InputCtr parentCallback = {this.callbackFunction}/>
                            </Col>
                        </Row>    
                        <div style={{height: '50px'}}>
                           <img src={'data:image/png;base64,'+ this.state.b64.encode(this.state.message)} alt="QR"/>
                           
                        </div>
                                       
                    </Container>
      
            )

    }

}
export default ImageSearch